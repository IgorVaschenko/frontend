import {
    Routes,
    Route,
} from "react-router-dom";

import { CardPage, HomePage } from '../pages'

import './app.css'

const App = () => {
    return (
        <Routes>
            <Route path='/' element={<HomePage />} />
            <Route path='/cart' element={<CardPage />} />
            <Route path='/*' element={<div>404</div>} />
        </Routes>
    );
}

export default App

