const CardPage = () => {
    return ( 
        <div>Card Page</div>
     );
}
 
export default CardPage;