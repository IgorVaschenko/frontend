import HomePage from "./home-page";
import CardPage from "./card-page";

export {
    HomePage,
    CardPage
}